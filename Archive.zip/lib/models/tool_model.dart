// tool_model
class Tool {
  final String name;
  final String status;

  Tool(this.name, this.status);
}
