class WeekOfTheYear {
  final DateTime start;
  final DateTime end;
  final String label;

  WeekOfTheYear({
    required this.start,
    required this.end,
    required this.label,
  });

  }
